from flask import Flask, render_template, request
import pandas as pd
from Test import generate_chart

app = Flask(__name__)

# Load the questions from the CSV file
questions_df = pd.read_csv('questions.csv')

@app.route('/')
def index():
    # Render the index.html template with questions data
    return render_template('index.html', questions=questions_df.to_dict(orient='records'))

@app.route('/submit', methods=['POST'])
def submit():
    # Collect user responses from the form
    user_responses = {key: int(value) for key, value in request.form.items()}

    # Convert user responses to DataFrame
    user_responses_df = pd.DataFrame(user_responses, index=[0])

    # Generate the chart and get the personality type and the personality traits values
    personality_type, my_sums = generate_chart(user_responses_df)

    # Render the results.html template and pass the personality type and the personality traits values
    return render_template('results.html',
                           personality_type=personality_type,
                           labels=list(my_sums.columns[0:5]),
                           data=list(my_sums.values[0][0:5]))

if __name__ == '__main__':
    app.run(debug=True)
